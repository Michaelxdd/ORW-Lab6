﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ProduktController : ApiController
    {
        private List<Produkt> produkty = new List<Produkt>() // lista moich produktów
        {
            new Produkt{Id = 1, Nazwa = "Jeansy Big-Star", Cena = 150, Rozmiar = "L" },
            new Produkt{Id = 2, Nazwa = "Jeansy Wrangler", Cena = 250, Rozmiar = "XL" },
            new Produkt{Id = 3, Nazwa = "Jeansy Lee", Cena = 310, Rozmiar = "XXL"},
            new Produkt{Id = 4, Nazwa = "T-Shirt Timberland", Cena = 130, Rozmiar = "XL"},
            new Produkt{Id = 5, Nazwa = "Bluza H&M", Cena = 90, Rozmiar = "M"},
        };
        public IEnumerable<Produkt> Get()
        {
            return produkty.ToList();
        }
        public IHttpActionResult Get(int id)
        {
            var produkt = produkty.Where(x => x.Id == id);
            if (produkt == null)
                return NotFound();
            return Ok(produkt);
        }
    }
}
